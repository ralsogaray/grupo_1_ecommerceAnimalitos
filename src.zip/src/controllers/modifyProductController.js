const renderModifyProduct = (req, res) =>{
    return res.render('users/modifyProduct.ejs')
}

module.exports = {renderModifyProduct}