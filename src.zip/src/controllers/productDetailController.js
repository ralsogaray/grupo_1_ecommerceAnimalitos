
const renderProductDetail = (req,res) => {
    return res.render('products/productDetail.ejs')
}


module.exports = {renderProductDetail}