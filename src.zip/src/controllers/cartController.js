const renderCart = (req,res) => {
    return res.render('users/cart.ejs')

}


module.exports = {renderCart}