


const renderRegister = (req,res) => {
    return res.render('users/register.ejs')

}


module.exports = {renderRegister}
