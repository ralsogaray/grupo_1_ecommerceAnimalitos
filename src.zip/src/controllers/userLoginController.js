



const renderLogin = (req,res) => {
    return res.render('users/login.ejs')

}




module.exports = {renderLogin}